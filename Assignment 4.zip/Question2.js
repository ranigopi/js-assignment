console.log("Question No.2:");

const student = {
  name: "Helsinki",
  age: 24,
  projects: {
    Dicegame: "Two players dice game using javascript",
  }
}
console.log("Destructure Object:");
const {name , age , projects:{Dicegame}} = student;
console.log(name, age, Dicegame);
