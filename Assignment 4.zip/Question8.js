console.log("Question No .8");
  
 let Ask = ()=> {
    function ask(question,yes,no){
        if(confirm(question)) yes()
        
  else no();
  
}
ask(
  " Do you agree ?",
  function() {alert ("you agreed.");
  console.log("Hello Friends");},
  function () { alert("you cancel the execution.");
    console.log("Byee Friends");
  }
 );
  }
  Ask();
  