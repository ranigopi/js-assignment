
console.log("Question no 7")
var n=prompt ("enter your Number to check whether the no. is prime or not");

function prime()
{

  if (n%2==0)
  {
    console.log(n,"Not a prime number");
  }
  else if(n%2==1)
  {
    console.log(n,"prime number");
  }
  
}
prime()

