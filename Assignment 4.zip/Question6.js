console.log("Question No.6");
var i = prompt("enter a Number:");

while(i<100){
  var i=prompt("enter a number which is greater than 100");
  if(i>=100){
  console.log("The number is",i);
  } 
}

 