
console.log("Question No.3");

let ShoppingList= ['Rice' ,  'Oil' , 

'Milk' , 'Chocolate' , 'Icecream' , 

'Orange'];

console.log(ShoppingList);
  
    let ShoppingBasket = [
      
     ...ShoppingList, "Mango" ,"Banana"];
  
   ShoppingBasket.push("Apple");
  
   console.log(ShoppingBasket);
