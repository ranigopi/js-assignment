 
 console.log("Question No.5");
 var i= prompt ("enter your sales:");

if(i < 0){
 var i=prompt("please enter a valid number:");
}
if(i>=0 && i<=5000){
    console.log(i,'The % of sales commission is 2%');
    let A = Math.round(i* 0.02);
    console.log("Total commission is:",A);
    }
else if(i > 5001 && i<=10000){
    console.log(i,'The % of sales commission is 5%');
    let b= Math.round(i * 0.05);
    console.log("Total commission is:",b);
}
else if(i > 10001 && i <=20000){
  console.log(i,'The % of sales commission is 7%');
  let c = Math.round(i*0.07);
  console.log("Total commission is:",c);
}
else if (i > 20000){
  console.log(i,"The % of commission is 10%");
  let d =Math.round( i * 0.1);
  console.log("Total commission is:",d);
   }