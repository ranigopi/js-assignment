console.log("Question No.1:");

for (let i=1; i <= 100; i++){
    if( i % 3 == 0 ){
        console.log(i,"the output is fizz");
        
    }
   if( i % 5 == 0 ){
        console.log(i,"the output is buzz");
        
    }
    if( ( i % 3 == 0 ) && ( i % 5 == 0 ) ){
        console.log(i,"the output is fizzbuzz");
    }
}